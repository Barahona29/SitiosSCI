﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace proyecto2APSW
{
    public partial class modelomadurez : System.Web.UI.Page
    {

        string cone = "workstation id=sistemaCI.mssql.somee.com;packet size=4096;user id=maikol1113_SQLLogin_1;pwd=6t75jgalrt;data source=sistemaCI.mssql.somee.com;persist security info=False;initial catalog=sistemaCI";
        SqlConnection con;
        SqlCommand cmdUsuario;
        

        public void Conexion()
        {
            con = new SqlConnection(cone);
            con.Open();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try 
            { 
            
            
            string valores = Request.Params.Get("valor");
            string[] datoss = valores.Split(';');
        
            Session["departamento"] = datoss[2];
            }
            catch (Exception ex) 
            {
                
            }
        }

        protected void btnGraficos_Click(object sender, EventArgs e)
        {
            string valores = Request.Params.Get("valor");
            string[] datoss = valores.Split(';');
            cargarPuntajes(datoss[2]);
          
        }

        void cargarPuntajes(string parametro)
        {
            
            Conexion();
            string strCadSQL;


            //Formar la sentencia SQL, un SELECT en este caso
            SqlDataReader myReader = null;
            strCadSQL = "select puntaje, idambiente from EvidenciaAmbiente where departamento = @parametro";
            SqlCommand myCommand = new SqlCommand(strCadSQL, con);
            myCommand.Parameters.Add(new SqlParameter("@parametro", parametro));

            myReader = myCommand.ExecuteReader();

            string[] datos = new string[5];
            int suma = 0;
            while (myReader.Read())
            {



               

                    
                

                if (myReader["idambiente"].ToString() == "1")
                {
                    suma = suma + Int32.Parse(myReader["puntaje"].ToString());
                }
                else if (myReader["idambiente"].ToString() == "2")
                {
                    suma = suma + Int32.Parse(myReader["puntaje"].ToString());
                }
                else if (myReader["idambiente"].ToString() == "3")
                {
                    suma = suma + Int32.Parse(myReader["puntaje"].ToString());
                }
                else if (myReader["idambiente"].ToString() == "4")
                {
                    suma = suma + Int32.Parse(myReader["puntaje"].ToString());
                }

                

                datos[3] = "0";
                

                
                    datos[2] = "0";



                datos[1] = "0";



                datos[0] = "0";





            }
            datos[4] = (suma / 4).ToString();

            con.Close();

            Response.Redirect("graficos.aspx?valores=1;" + datos[0] + ";" + datos[1] + ";" + datos[2] + ";" + datos[3] + ";" + datos[4]);
        }
    }
}