﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace proyecto2APSW
{
    public partial class compromiso : System.Web.UI.Page
    {

        string cone = "workstation id=sistemaCI.mssql.somee.com;packet size=4096;user id=maikol1113_SQLLogin_1;pwd=6t75jgalrt;data source=sistemaCI.mssql.somee.com;persist security info=False;initial catalog=sistemaCI";
        SqlConnection con;
        SqlCommand cmdUsuario;

        public void Conexion()
        {
            con = new SqlConnection(cone);
            con.Open();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            encabezado();
            cargarVaras();
            try { 

                if (!IsPostBack) 
                { 
                    string parametro =  Request.Params.Get("valor");
                    string[] datos = parametro.Split(';');
                    if (datos[0].ToString() == "1")
                    {
                        lblCodigo.Text = "Evidencia: " + datos[1];
                        lblCodigo.Visible = true;
                        lblEstado.Text = "Estado: "+ estadoEvidencia(datos[1]);
                        lblEstado.Visible = true;
                        lblo.Visible = true;
                        lblTextoLink.Visible = true;

                        txtlinkEvid.Visible = true;
                        FileUpload1.Visible = true;
                        btnEnviar.Visible = true;
                    }
                    else if (datos[0].ToString() == "2") {
                        descargar(datos[1]);
                    }




                }

            }
            catch (Exception ex) 
            {
            
            }
        }

        void cargarVaras()
        {
            string dep = Session["departamento"] as String;
            Table1.Rows.Clear();
            Conexion();
            string strCadSQL;


            //Formar la sentencia SQL, un SELECT en este caso
            SqlDataReader myReader = null;
            strCadSQL = "";
            
                strCadSQL = "select * from EvidenciaAmbiente where idambiente = 1 and Revision='Aprobada' and departamento=@dep";
            
            
                
           

            SqlCommand myCommand = new SqlCommand(strCadSQL, con);
            myCommand.Parameters.Add(new SqlParameter("@dep",dep));

            myReader = myCommand.ExecuteReader();

            encabezado();
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
            while (myReader.Read())
            {
                string fechainicio = myReader["inicio_de_apertura"].ToString();
             

                string fechafin = myReader["fin_de_apertura"].ToString();
             

                string fechaActual = DateTime.Now.ToShortDateString();

                DateTime fechaAct = Convert.ToDateTime(fechaActual, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);

                DateTime fechaini = Convert.ToDateTime(fechainicio, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);

                DateTime fechaf = Convert.ToDateTime(fechafin, System.Globalization.CultureInfo.GetCultureInfo("ur-PK").DateTimeFormat);


                if (fechaAct >= fechaini && fechaAct <= fechaf)
                {
                    nuevaTabla(myReader["codigo"].ToString(), myReader["Nivel"].ToString(), myReader["Descripción"].ToString(), myReader["tipo_evidencia"].ToString(), myReader["Evidencia"].ToString(), myReader["Cumplimiento"].ToString(), myReader["link"].ToString(), myReader["archivo"].ToString(), myReader["puntaje"].ToString(), myReader["codigo"].ToString());

                }


            }

            con.Close();
        }
        void nuevaTabla(string codigo, string Nivel, string Descripcion, string Estado, string Evidencia, string Cumplimiento, string link, string archivo, string puntaje, string titulo)
        {

         
            
            TableRow row2 = new TableRow();
      

            TableCell cell1 = new TableCell();
            TableCell cell2 = new TableCell();
            TableCell cell3 = new TableCell();
            TableCell cell4 = new TableCell();
            TableCell cell5 = new TableCell();
            TableCell cell6 = new TableCell();
            TableCell cell7 = new TableCell();
            TableCell cell71 = new TableCell();
            TableCell cell72 = new TableCell();
          


            cell1.Text = codigo;
            cell2.Text = Nivel;
          
            cell4.Text = Estado;
                   
            cell72.Text = puntaje;
          


            Literal lit = new Literal();
       
            lit.Text = Descripcion;

            Literal lit2 = new Literal();

            // lit.Text = "<button id='" + titulo + "' onclick='cargar(this)' style='  border: none; color: white; text-align: center; text - decoration: none; display: inline-block; margin: 4px 2px; transition-duration: 0.4s; cursor: pointer; border-radius: 5px; background-color: black; font-size: 17px; ' type='button'>Cargar</button>";
            lit2.Text = Evidencia;

            Literal lit3 = new Literal();
            if (Cumplimiento == "Sí") 
            {
                lit3.Text = "<label class='switch'> <input type='checkbox' id='"+titulo+ "' onclick='cargar(this)' checked='checked'><div class='slider round'></div></label>";

            }
            else if (Cumplimiento=="No")
            {
                lit3.Text = "<div style='text-align: center;'><label class='switch'> <input type='checkbox' id='" + titulo + "' onclick='cargar(this)'><div class='slider round'></div></label></div>";

            }
            


            cell3.Controls.Add(lit);
            cell5.Controls.Add(lit2);

            Literal lit4 = new Literal();
            if (!link.Equals(""))
            {
                lit4.Text = "<a href='" + link + "'> Link de la evidencia </a>";
            }
            else {
                lit4.Text = "";
            }
            

            cell6.Controls.Add(lit3);

            cell7.Controls.Add(lit4);


            Literal lit5 = new Literal();
            if (!archivo.Equals(""))
            {
                lit5.Text = "<input type='button' class='btnDescargar' onclick='descargar(this)' name=" + titulo+" value='Descargar' />";

            }
            else
            {
                lit5.Text = "";

            }
            cell71.Controls.Add(lit5);

            row2.Cells.Add(cell1);

            row2.Cells.Add(cell2);

            row2.Cells.Add(cell3);

            row2.Cells.Add(cell4);

            row2.Cells.Add(cell5);

            row2.Cells.Add(cell6);

            row2.Cells.Add(cell7);

            row2.Cells.Add(cell71);

            row2.Cells.Add(cell72);

            Table1.Rows.Add(row2);

        }

        protected void btnEnviar_Click(object sender, EventArgs e)
        {
            try
            {
                //método de conexión
                string parametro = Request.Params.Get("valor");
                string[] datos = parametro.Split(';');
                Conexion();
                if (txtlinkEvid.Text != "")
                {
                    cmdUsuario = new SqlCommand("update EvidenciaAmbiente set link = @link, Cumplimiento='Sí' where codigo=@cod", con);
                    cmdUsuario.Parameters.Add(new SqlParameter("@link", txtlinkEvid.Text));
                    cmdUsuario.Parameters.Add(new SqlParameter("@cod", datos[1]));
                   
                }
                else {
                    string nombreArch = FileUpload1.FileName;
                    string[] datosArch = nombreArch.Split('.');
                    string tipoArch = datosArch[1];
                    cmdUsuario = new SqlCommand("update EvidenciaAmbiente set archivo = @arch, Cumplimiento='Sí', tipoarchivo=@tipoarch where codigo=@cod", con);
                    cmdUsuario.Parameters.Add(new SqlParameter("@arch", SqlDbType.VarBinary)).Value = FileUpload1.FileBytes;
                    cmdUsuario.Parameters.Add(new SqlParameter("@tipoarch", tipoArch));
                    cmdUsuario.Parameters.Add(new SqlParameter("@cod", datos[1]));
                }
               

                cmdUsuario.ExecuteNonQuery();
                con.Close();
                actualizarPuntajeyEstado(datos[1]);

                cargarVaras();
                
                Response.Write("<script>alert('Evidencia enviada correctamente');</script>");
               


            }
            //en caso de error se muestra un mensaje
            catch (Exception ex)
            {
               
                Response.Write("<script>alert('Error en la base de datos " + ex.Message + "');</script>");
            }
        }

        void encabezado() 
        {

            TableRow row = new TableRow();
          
            TableHeaderCell hcell1 = new TableHeaderCell();
            TableHeaderCell hcell2 = new TableHeaderCell();
            TableHeaderCell hcell3 = new TableHeaderCell();
            TableHeaderCell hcell4 = new TableHeaderCell();
            TableHeaderCell hcell5 = new TableHeaderCell();
            TableHeaderCell hcell6 = new TableHeaderCell();
            TableHeaderCell hcell7 = new TableHeaderCell();
            TableHeaderCell hcell8 = new TableHeaderCell();
            TableHeaderCell hcell9 = new TableHeaderCell();

         



            hcell1.Text = "Código";
            hcell2.Text = "Nivel";
            hcell3.Text = "Descripción";
            hcell4.Text = "Tipo";
            hcell5.Text = "Evidencia";
            hcell6.Text = "Cumplimiento";
            hcell7.Text = "Link";
            hcell8.Text = "Archivo";
            hcell9.Text = "Puntaje";

         


           


            row.Cells.Add(hcell1);

            row.Cells.Add(hcell2);

            row.Cells.Add(hcell3);

            row.Cells.Add(hcell4);

            row.Cells.Add(hcell5);

            row.Cells.Add(hcell6);



            row.Cells.Add(hcell7);

            row.Cells.Add(hcell8);

            row.Cells.Add(hcell9);

            Table1.Rows.Add(row);

        }

        void descargar(string id) 
        {
           
            byte[] bytes;
            string fileName, contentType;
            string constr = "workstation id=sistemaCI.mssql.somee.com;packet size=4096;user id=maikol1113_SQLLogin_1;pwd=6t75jgalrt;data source=sistemaCI.mssql.somee.com;persist security info=False;initial catalog=sistemaCI";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select codigo, archivo, tipoarchivo from EvidenciaAmbiente where codigo=@Id";
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        sdr.Read();
                        bytes = (byte[])sdr["archivo"];
                        contentType = sdr["tipoarchivo"].ToString();
                        fileName = sdr["codigo"].ToString()+"."+ sdr["tipoarchivo"].ToString();
                    }
                    con.Close();
                }
            }
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = contentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.End();
        }

        void actualizarPuntajeyEstado(string codigo)
        {
            
            Conexion();
            string strCadSQL;


            //Formar la sentencia SQL, un SELECT en este caso
          
           

            strCadSQL = "update EvidenciaAmbiente set puntaje = 20, Estado='Entregado' where Cumplimiento='Sí' and codigo=@codigo and tipo_evidencia='Opcional'";

            SqlCommand myCommand = new SqlCommand(strCadSQL, con);
            
            myCommand.Parameters.AddWithValue("@codigo", codigo);

            myCommand.ExecuteNonQuery();

            con.Close();



            Conexion();
            string strCadSQL2;


            //Formar la sentencia SQL, un SELECT en este caso



            strCadSQL2 = "update EvidenciaAmbiente set Estado='Entregado' where codigo=@codigo and Cumplimiento='Sí'";

            SqlCommand myCommand2 = new SqlCommand(strCadSQL2, con);

            myCommand2.ExecuteNonQuery();

            con.Close();
        }

        public string estadoEvidencia(string codigo) 
        {
            Conexion();
            string strCadSQL;


            //Formar la sentencia SQL, un SELECT en este caso
            SqlDataReader myReader = null;
            strCadSQL = "";

            strCadSQL = "select Estado from EvidenciaAmbiente where codigo = @codigo";

            SqlCommand myCommand = new SqlCommand(strCadSQL, con);
            myCommand.Parameters.Add(new SqlParameter("@codigo",codigo));

            myReader = myCommand.ExecuteReader();

            string estEv = "";

            while (myReader.Read())
            {


                estEv = myReader["Estado"].ToString();
             

            }

            con.Close();

            return estEv;
        }

    }
}